# Forecast-the-AC-power-consumption
The data contains power for multiple ACs at some hotel in Gurgaon.

1.Identify patterns/trends in the data? Which AC was used the most/least? 

2.Relate this power data with the outside temperature of Gurgaon. (Feel free to use temperature data from any website online. 

3.How will you fetch that data in your analysis?

4.Using the power data, predict/forecast the power consumption?
